from django.urls import path
from . import views
urlpatterns = [
    path('',views.index,name='home'),
    path('remove/<str:id>/',views.removeItem,name='removeItem'),
    path('remove/',views.remove,name='remove'),
    path('remove/<str:id>/',views.remove,name='remove'),
    path('dashboard/',views.home,name='dashboard'),
    path('addstock/',views.addStock,name='add'),
]
