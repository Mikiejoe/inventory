from django.contrib.auth.forms import ModelForm

class User:
    pass