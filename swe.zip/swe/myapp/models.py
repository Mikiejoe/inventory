from django.db import models

# Create your models here.
class Stock(models.Model):
    name = models.CharField(max_length=200,unique=True)
    quantity = models.IntegerField()

    def __str__(self) -> str:
        return self.name