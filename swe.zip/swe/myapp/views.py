from django.shortcuts import render,redirect,get_object_or_404
from django.contrib.auth.decorators import login_required
# from django
from .models import Stock
# Create your views here.
@login_required
def home(request):
    stock = Stock.objects.all()
    context = {'stocks':stock}
    return render(request,'myapp/pages/dashboard.html',context)

@login_required
def index(request):
    return render(request,'index.html')

@login_required
def addStock(request):
    if request.method == 'POST':
        name = request.POST['name']
        quantity = request.POST['quantity']
        stock = Stock(name=name,quantity=quantity)
        stock.save()
        return redirect('home')
    return render(request,'myapp/pages/addstock.html')

def remove(request):
    stock = Stock.objects.all()
    context = {'stocks':stock}
    return render(request,'myapp/pages/remove.html',context)
    
def removeItem(request,id):
    stock = Stock.objects.get(id=id)
    stock.delete()
    # stock.save()
    return redirect('home')
    